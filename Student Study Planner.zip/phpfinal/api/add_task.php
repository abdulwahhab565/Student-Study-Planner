<?php
require_once 'config.php';

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['subject']) || !isset($data['task']) || !isset($data['due_date'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO tasks (subject, task, due_date) VALUES (?, ?, ?)");
    $success = $stmt->execute([$data['subject'], $data['task'], $data['due_date']]);
    
    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Task added successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to add task']);
    }
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>