<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Student Study Planner - Dark Theme</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    color: #e6e6e6;
    padding: 20px;
}

.planner-container {
    background-color: #1e1e2e;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
    width: 100%;
    max-width: 700px;
    border: 1px solid #39394c;
}

.header {
    text-align: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #39394c;
}

h1 {
    color: #7b68ee;
    font-size: 2.2rem;
    margin-bottom: 0.5rem;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.subtitle {
    color: #a9a9b2;
    font-size: 1rem;
}

.form-vertical {
    display: flex;
    flex-direction: column;
    gap: 1.2rem;
}

.form-group {
    margin-bottom: 0.5rem;
    width: 100%;
}

label {
    display: block;
    margin-bottom: 0.6rem;
    font-weight: 600;
    color: #d0d0d7;
}

input, textarea {
    width: 100%;
    padding: 14px;
    background-color: #2a2a3e;
    border: 1px solid #39394c;
    border-radius: 8px;
    font-size: 1rem;
    color: #e6e6e6;
    transition: all 0.3s ease;
}

input:focus, textarea:focus {
    outline: none;
    border-color: #7b68ee;
    box-shadow: 0 0 0 2px rgba(123, 104, 238, 0.3);
}

input::placeholder, textarea::placeholder {
    color: #6b6b7f;
}

textarea {
    min-height: 100px;
    resize: vertical;
}

button {
    padding: 16px;
    background: linear-gradient(to right, #7b68ee, #6a5acd);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    width: 100%;
    margin-top: 0.5rem;
}

button:hover {
    background: linear-gradient(to right, #6a5acd, #5d49c0);
    transform: translateY(-2px);
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.25);
}

button:active {
    transform: translateY(0);
}

.tasks {
    margin-top: 2rem;
    background-color: #252536;
    border-radius: 10px;
    padding: 1.5rem;
    border: 1px solid #39394c;
}

.tasks-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 0.8rem;
    border-bottom: 1px solid #39394c;
}

.tasks-title {
    color: #d0d0d7;
    font-size: 1.4rem;
}

.tasks-count {
    background-color: #7b68ee;
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 600;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 0.8rem;
}

th, td {
    padding: 0.8rem;
    text-align: left;
    font-size: 0.95rem;
}

th {
    background-color: #2a2a3e;
    color: #a9a9b2;
    font-weight: 600;
    border-bottom: 2px solid #39394c;
}

td {
    border-bottom: 1px solid #39394c;
    color: #e6e6e6;
}

tr:last-child td {
    border-bottom: none;
}

.delete-btn {
    background: #e94560;
    padding: 0.4rem 0.8rem;
    border-radius: 5px;
    font-size: 0.85rem;
    width: auto;
}

.delete-btn:hover {
    background: #d43550;
    transform: none;
}

.empty {
    text-align: center;
    padding: 2rem;
    color: #6b6b7f;
    font-style: italic;
}

.loading {
    text-align: center;
    padding: 1.5rem;
    color: #7b68ee;
}

.error {
    color: #ff6b6b;
    padding: 0.8rem;
    background: rgba(255, 107, 107, 0.1);
    border-radius: 6px;
    margin-top: 0.8rem;
    border-left: 4px solid #ff6b6b;
}

.success {
    color: #51ec8f;
    padding: 0.8rem;
    background: rgba(81, 236, 143, 0.1);
    border-radius: 6px;
    margin-top: 0.8rem;
    border-left: 4px solid #51ec8f;
}

@media (max-width: 650px) {
    .planner-container {
        padding: 1.5rem;
    }
}

.task-date {
    color: #a9a9b2;
    font-size: 0.85rem;
}

.task-subject {
    font-weight: 600;
    color: #7b68ee;
}

.urgency-high {
    border-left: 4px solid #e94560;
}

.urgency-medium {
    border-left: 4px solid #ff9f43;
}

.urgency-low {
    border-left: 4px solid #51ec8f;
}
</style>
</head>
<body>
<div class="planner-container">
    <div class="header">
        <h1>Student Study Planner</h1>
        <p class="subtitle">Organize your study tasks efficiently</p>
    </div>
    
    <form id="study-planner-form" aria-label="Study planner form">
        <div class="form-vertical">
            <!-- Subject Input -->
            <div class="form-group">
                <label for="subject">Subject</label>
                <input type="text" id="subject" name="subject" placeholder="e.g. Mathematics" required>
            </div>
            
            <!-- Task Input -->
            <div class="form-group">
                <label for="task">Task</label>
                <textarea id="task" name="task" placeholder="Describe the study task in detail..." required></textarea>
            </div>
            
            <!-- Due Date Input -->
            <div class="form-group">
                <label for="due-date">Due Date</label>
                <input type="date" id="due-date" name="due-date" required>
            </div>
        </div>
        
        <div id="form-message"></div>
        
        <div class="btn-row">
            <button type="submit">Add To Planner</button>
        </div>
    </form>
    
    <section class="tasks" aria-live="polite">
        <div class="tasks-header">
            <h2 class="tasks-title">Planned Tasks</h2>
            <span class="tasks-count" id="tasks-count">3 tasks</span>
        </div>
        
        <div id="tasks-container">
            <!-- Tasks will be loaded here -->
            <div class="loading">Loading your tasks...</div>
        </div>
    </section>
</div>

<script>
// For demonstration purposes, we'll simulate a backend using localStorage
// In a real application, you would replace these with actual API calls

// Simulated API endpoints
const simulateDelay = () => new Promise(resolve => setTimeout(resolve, 300));

// Simulated database using localStorage
const STORAGE_KEY = 'study_planner_tasks_db';

// Initialize with sample data if empty
function initDatabase() {
    if (!localStorage.getItem(STORAGE_KEY)) {
        const sampleTasks = [
            { 
                id: 1, 
                subject: 'Mathematics', 
                task: 'Complete calculus problem set', 
                due_date: '2025-09-10',
                urgency: 'high'
            },
            { 
                id: 2, 
                subject: 'Physics', 
                task: 'Read chapter on thermodynamics', 
                due_date: '2025-09-15',
                urgency: 'medium'
            },
            { 
                id: 3, 
                subject: 'Literature', 
                task: 'Write essay on modern poetry', 
                due_date: '2025-09-20',
                urgency: 'low'
            }
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sampleTasks));
    }
}

// Simulated API functions
async function getTasks() {
    await simulateDelay();
    initDatabase();
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
}

async function addTask(task) {
    await simulateDelay();
    const tasks = await getTasks();
    const newId = tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1;
    
    // Determine task urgency based on due date
    const today = new Date();
    const dueDate = new Date(task.due_date);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    let urgency = 'low';
    if (diffDays <= 2) urgency = 'high';
    else if (diffDays <= 7) urgency = 'medium';
    
    const newTask = { ...task, id: newId, urgency };
    tasks.push(newTask);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    return newTask;
}

async function deleteTask(id) {
    await simulateDelay();
    const tasks = await getTasks();
    const filteredTasks = tasks.filter(task => task.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filteredTasks));
    return true;
}

// DOM elements
const form = document.getElementById('study-planner-form');
const formMessage = document.getElementById('form-message');
const tasksContainer = document.getElementById('tasks-container');
const tasksCount = document.getElementById('tasks-count');

// Show message function
function showMessage(message, type = 'error') {
    formMessage.textContent = message;
    formMessage.className = type;
    setTimeout(() => {
        formMessage.textContent = '';
        formMessage.className = '';
    }, 3000);
}

// Format date for display (Month/Day/Year format)
function formatDate(dateString) {
    const date = new Date(dateString);
    const month = date.toLocaleString('en-US', { month: 'short' });
    const day = date.getDate();
    const year = date.getFullYear();
    return `${month} ${day}, ${year}`;
}

// Calculate days until due
function getDaysUntilDue(dateString) {
    const today = new Date();
    const dueDate = new Date(dateString);
    const diffTime = dueDate.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

// Load tasks from database
async function loadTasks() {
    try {
        tasksContainer.innerHTML = '<div class="loading">Loading tasks...</div>';
        const tasks = await getTasks();
        updateTasksCount(tasks.length);
        renderTasks(tasks);
    } catch (error) {
        console.error('Error loading tasks:', error);
        tasksContainer.innerHTML = '<div class="error">Failed to load tasks. Please try again.</div>';
    }
}

// Update tasks count
function updateTasksCount(count) {
    tasksCount.textContent = `${count} task${count !== 1 ? 's' : ''}`;
}

// Render tasks to the UI
function renderTasks(tasks) {
    if (!tasks || tasks.length === 0) {
        tasksContainer.innerHTML = '<div class="empty">No tasks yet — add one above to get started!</div>';
        updateTasksCount(0);
        return;
    }
    
    // Sort tasks by due date (soonest first)
    tasks.sort((a, b) => new Date(a.due_date) - new Date(b.due_date));
    
    let html = `
        <table aria-describedby="Planned study tasks">
            <thead>
                <tr>
                    <th>Subject</th>
                    <th>Task</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    for (const task of tasks) {
        const daysUntilDue = getDaysUntilDue(task.due_date);
        let dueText = formatDate(task.due_date);
        
        if (daysUntilDue < 0) {
            dueText += ' <span style="color:#e94560">(Overdue)</span>';
        } else if (daysUntilDue === 0) {
            dueText += ' <span style="color:#ff9f43">(Today)</span>';
        } else if (daysUntilDue === 1) {
            dueText += ' <span style="color:#ff9f43">(Tomorrow)</span>';
        } else if (daysUntilDue <= 7) {
            dueText += ` <span style="color:#ff9f43">(${daysUntilDue} days)</span>`;
        }
        
        html += `
            <tr class="urgency-${task.urgency}">
                <td><span class="task-subject">${escapeHtml(task.subject)}</span></td>
                <td>${escapeHtml(task.task)}</td>
                <td><span class="task-date">${dueText}</span></td>
                <td>
                    <button data-id="${task.id}" class="delete-btn">Delete</button>
                </td>
            </tr>
        `;
    }
    
    html += '</tbody></table>';
    tasksContainer.innerHTML = html;
    
    // Attach delete handlers
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = parseInt(btn.getAttribute('data-id'));
            deleteTaskHandler(id);
        });
    });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Add a new task
async function addTaskHandler(subject, task, dueDate) {
    try {
        await addTask({ subject, task, due_date: dueDate });
        showMessage('Task added successfully!', 'success');
        loadTasks(); // Reload tasks from database
    } catch (error) {
        console.error('Error adding task:', error);
        showMessage('Failed to add task. Please try again.');
    }
}

// Delete a task
async function deleteTaskHandler(id) {
    if (!confirm('Are you sure you want to delete this task?')) return;
    
    try {
        await deleteTask(id);
        showMessage('Task deleted successfully!', 'success');
        loadTasks(); // Reload tasks from database
    } catch (error) {
        console.error('Error deleting task:', error);
        showMessage('Failed to delete task. Please try again.');
    }
}

// Form submission handler
form.addEventListener('submit', async e => {
    e.preventDefault();
    const subject = document.getElementById('subject').value.trim();
    const task = document.getElementById('task').value.trim();
    const dueDate = document.getElementById('due-date').value;
    
    if (!subject || !task || !dueDate) {
        showMessage('Please fill all fields.');
        return;
    }
    
    await addTaskHandler(subject, task, dueDate);
    form.reset();
    document.getElementById('subject').focus();
});

// Initialize the application
loadTasks();

// Set minimum date to today for the date picker
const today = new Date().toISOString().split('T')[0];
document.getElementById('due-date').setAttribute('min', today);
</script>
</body>
</html>